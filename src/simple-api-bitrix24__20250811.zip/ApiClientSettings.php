<?php

declare(strict_types=1);

namespace SimpleApiBitrix24;


use SimpleApiBitrix24\Connectors\Handlers\OperationTimeLimitHandler;
use SimpleApiBitrix24\Connectors\Handlers\QueryLimitExceededHandler;
use SimpleApiBitrix24\DatabaseCore\Models\User;
use SimpleApiBitrix24\Enums\AuthType;
use SimpleApiBitrix24\Models\Webhook;
use SimpleApiBitrix24\Utils\Helper;

class ApiClientSettings
{
    private bool $webhookAuthEnabled;
    private bool $tokenAuthEnabled;
    private Webhook|User|null $defaultConnection = null;
    private ?QueryLimitExceededHandler $queryLimitExceededService = null;
    private ?OperationTimeLimitHandler $operationTimeLimitService = null;

    public function __construct(AuthType $authType)
    {
        $this->webhookAuthEnabled = $authType === AuthType::WEBHOOK;
        $this->tokenAuthEnabled = $authType === AuthType::TOKEN;
    }

    public function setDefaultConnection(Webhook|User $credentials): ApiClientSettings
    {
        $this->defaultConnection = $credentials;
        return $this;
    }

    public function setQueryLimitExceededService(
        bool $handleEnabled,
        int $usleep = QueryLimitExceededHandler::USLEEP_DEFAULT
    ): ApiClientSettings {
        $this->queryLimitExceededService = new QueryLimitExceededHandler($handleEnabled, $usleep);
        return $this;
    }

    public function setOperationTimeLimitService(
        bool $handleEnabled,
        int $usleep = OperationTimeLimitHandler::USLEEP_DEFAULT
    ): ApiClientSettings {
        $this->operationTimeLimitService = new OperationTimeLimitHandler($handleEnabled, $usleep);
        return $this;
    }

    public function isWebhookAuthEnabled(): bool
    {
        return $this->webhookAuthEnabled;
    }

    public function isTokenAuthEnabled(): bool
    {
        return $this->tokenAuthEnabled;
    }

    public function getDefaultConnection(): Webhook|User|null
    {
        if ($this->webhookAuthEnabled && $this->defaultConnection === null) {
            return new Webhook('null');
        }

        return $this->defaultConnection;
    }

    public function getQueryLimitExceededService(): QueryLimitExceededHandler
    {
        if (null === $this->queryLimitExceededService) {
            $this->queryLimitExceededService = new QueryLimitExceededHandler(false);
        }

        return $this->queryLimitExceededService;
    }

    public function getOperationTimeLimitService(): OperationTimeLimitHandler
    {
        if (null === $this->operationTimeLimitService) {
            $this->operationTimeLimitService = new OperationTimeLimitHandler(false);
        }

        return $this->operationTimeLimitService;
    }
}
