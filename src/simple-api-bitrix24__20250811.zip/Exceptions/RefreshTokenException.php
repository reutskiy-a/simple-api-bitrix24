<?php

declare(strict_types=1);

namespace SimpleApiBitrix24\Exceptions;

class RefreshTokenException extends Bitrix24ResponseException
{

}
