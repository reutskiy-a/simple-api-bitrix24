<?php

namespace SimpleApiBitrix24\Enums;

enum AuthType
{
    case WEBHOOK;
    case TOKEN;
}
