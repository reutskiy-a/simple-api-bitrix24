<?php

declare(strict_types=1);

namespace SimpleApiBitrix24;

use PDO;

class TableManager
{
    private ApiDatabaseConfig $dbConfig;

    public function __construct(ApiDatabaseConfig $dbConfig)
    {
        $this->dbConfig = $dbConfig;
    }

    public function createUsersTableIfNotExists()
    {
        return match($this->dbConfig->pdo->getAttribute(PDO::ATTR_DRIVER_NAME)) {
            'mysql' => $this->mysqlCrateUsersTableIfNotExists(),
            'pgsql' => $this->pgsqlCrateUsersTableIfNotExists(),
            'sqlite' => $this->sqliteCrateUsersTableIfNotExists(),
            'default' => false
        };
    }

    private function mysqlCrateUsersTableIfNotExists(): void
    {

    }

    private function sqliteCrateUsersTableIfNotExists(): void
    {

    }

    private function pgsqlCrateUsersTableIfNotExists(): void
    {

    }
}
