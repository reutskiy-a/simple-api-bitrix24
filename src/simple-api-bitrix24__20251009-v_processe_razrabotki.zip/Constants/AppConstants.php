<?php

declare(strict_types=1);

namespace SimpleApiBitrix24\Constants;

class AppConstants
{
    public const APP_INFO = 'reutskiy-a/simple-api-bitrix24';
}
