<?php

namespace SimpleApiBitrix24\Models;

final class Webhook
{
    public function __construct(
        private string $url
    ) {

    }

    public function getUrl(): string
    {
        return $this->url;
    }
}