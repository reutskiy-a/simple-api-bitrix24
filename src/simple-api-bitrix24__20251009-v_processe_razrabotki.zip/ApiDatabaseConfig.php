<?php

declare(strict_types=1);

namespace SimpleApiBitrix24;

use PDO;

final class ApiDatabaseConfig
{
    public function __construct(
        public readonly PDO    $pdo,
        public readonly string $tableName,
        public readonly string $userIdColumnName,               // db type: int (big_int unsigned) NOT NULL
        public readonly string $memberIdColumnName,             // db type: string (100) NOT NULL
        public readonly string $isAdminColumnName,              // db type: bool (1) NOT NULL DEFAULT 0
        public readonly string $authTokenColumnName,            // db type: string (100) NOT NULL
        public readonly string $refreshTokenColumnName,         // db type: string (100) NOT NULL
        public readonly string $domainColumnName,               // db type: string (200) NOT NULL
        public readonly string $clientIdColumnName,             // db type: string (100) NOT NULL
        public readonly string $clientSecretColumnName,         // db type: string (100) NOT NULL
        public readonly string $createdAtColumnName,            // db type: timestamp NOT NULL
        public readonly string $updatedAtColumnName,            // db type: timestamp NOT NULL
    ) {

    }
}
